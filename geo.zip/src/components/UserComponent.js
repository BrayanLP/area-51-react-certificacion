import React, { Component} from 'react'
import User from './User'
import UserList from './UserList'

const data = [{
    name : 'BrayanLP',
    email: 'brayansystemlp@gmail.com',
    image: 'https://prueba.img',
    location: {
        state: 'Lima',
        city: 'Lima',
        street: 'Miraflores'
    }
}]
const API = "https://randomuser.me/api/?results=50"
class UserComponent extends Component {
    constructor(props){
        super(props)
        this.state ={
            data: []
        }
    }
    componentDidMount(){
        console.log('entre')
        fetch(API)
        .then(res => res.json())
        .then(data => {
            const { results } = data 
            console.log(results)   
            this.setState({data: results})
        })
    }
    render(){
        const { data} = this.state
        return( 
          <UserList data={data}></UserList> 

        )
    }
}
export default UserComponent